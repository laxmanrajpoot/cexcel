from django.shortcuts import render,HttpResponse,HttpResponseRedirect
import pandas as pd
from openpyxl import load_workbook

def index(request):
    return render(request,"index.html")

def add_user(request):
    return render(request,"form.html")

def upload_xlsfile(request):
    return render(request,"upload_file.html")
def sucess(request):
    return render(request,"sucess.html")

def form_view(request):
    try:
        if request.method=='POST':
            Sdepartment=request.POST.get('Sdepartment')
            Avm=request.POST.get("Avm")
            Associate_id=request.POST.get('Associate_id')
            Name=request.POST.get('Name')
            Grade=request.POST.get('Grade')
            Bu=request.POST.get('Bu')
            Project_id=request.POST.get('Project_id')
            Project_name=request.POST.get('Project_name')
            Classification=request.POST.get('Classification')
            Pm_id=request.POST.get('Pm_id')
            Pm_name=request.POST.get('Pm_name')
            Account_id=request.POST.get('Account_id')
            Account_name=request.POST.get('Account_name')
            Customer_id=request.POST.get('Customer_id')
            Parent_cus=request.POST.get('Parent_cus')
            Ptag=request.POST.get('Ptag')
            Stag=request.POST.get('Stag')
            Hm_id=request.POST.get('Hm_id')
            Billability=request.POST.get('Billability')
            Country=request.POST.get('Country')
            State=request.POST.get('State')
            City=request.POST.get('City')
            Office_loc=request.POST.get('Office_loc')
            Ons_off=request.POST.get('Ons_off')
            Start_date=request.POST.get('Start_date')
            End_date=request.POST.get('End_date')
            Assignment_status=request.POST.get('Assignment_status')
            Percent_all=request.POST.get('Percent_all')
            Department=request.POST.get('Department')
            Vertical=request.POST.get('Vertical')
            Pstart_date=request.POST.get('Pstart_date')
            Pend_date=request.POST.get('Pend_date')
            Market_na=request.POST.get('Market_na')
            Market=request.POST.get('Market')
            Market_unit=request.POST.get('Market_unit')
            Poll_id=request.POST.get('Poll_id')

            file="C:/Users/2152504/OneDrive - Cognizant/Desktop/demo1.xlsx"
            wb=load_workbook(file)
            sheet=wb.active
            n=[[Sdepartment,Avm,Associate_id,Name,Grade,Bu,Project_id,Project_name,Classification,Pm_id,Pm_name,Account_id,Account_name,Customer_id,Parent_cus,
            Ptag,Stag,Hm_id,Billability,Country,State,City,Office_loc,Ons_off,Start_date,End_date,Assignment_status,Percent_all,Department,Vertical,Pstart_date,Pend_date,
            Market_na,Market,Market_unit,Poll_id]]
            for d in n:
                sheet.append(d)
            wb.save(filename='C:/Users/2152504/OneDrive - Cognizant/Desktop/demo1.xlsx')
        
    except:
        pass
    return render(request,"sucess.html")
